
## 编译

export SDE=/root/bf-sde-9.1.0
export SDE_INSTALL=$SDE/install
export PATH=$SDE_INSTALL/bin:$PATH


cd $SDE/pkgsrc/p4-build
./autogen.sh

$SDE/pkgsrc/p4-build/configure --with-tofino --with-p4c=p4c --prefix=$SDE_INSTALL \
--bindir=$SDE_INSTALL/bin \
P4_NAME=simple_ipv6 \
P4_PATH=/root/my_p4/simple_ipv6/simple_ipv6.p4 \
P4_VERSION=p4-16 P4_ARCHITECTURE=tna \
LDFLAGS="-L$SDE_INSTALL/lib" \
--enable-thrift

make

make install

## 检查进程

ps -ax | grep switchd
sudo kill <proces id>

## 运行p4

cd ~/my_p4/simple_ipv6
chmod +777 ./*
./run_p4.sh

## 下发流表

cd ~/my_p4/xzh/simple_ipv6
chmod +777 ./*
./run_setup.sh

## 激活端口

ucli
pm port-add 5/0 10g none
pm port-add 9/0 10g none
pm port-enb 5/0
pm port-enb 9/0
pm show
